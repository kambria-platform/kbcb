char *getGitPath();
char *getHookPath(char *filename);
void addRemote(char *remote, char *url);
void removeRemote(char *remote);
